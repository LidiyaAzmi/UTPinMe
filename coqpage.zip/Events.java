public class Events{
    String eventName; 
    String eventDetails;
    String eventDescription;
    
    public void setName(String eventName) {
        this.eventName = eventName;
    }

    public void setDetails(String eventDetails) {
        this.eventDetails = eventDetails;
    }    
    
    public void setDescription(String eventDescription) {
        this.eventDescription = eventDescription;
    }
    
    public String getName (){
        return eventName;
    }
    
    public String getDetails (){
        return eventDetails;
    }
    
    public String getDescription (){
        return eventDescription;
    }
    
}
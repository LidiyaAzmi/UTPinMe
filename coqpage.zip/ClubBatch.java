import java.util.ArrayList;

public class ClubBatch{
    private ArrayList<String> clubs;

    public ClubBatch(){
        this.clubs = new ArrayList<String>();
    }

    public void addClub(Clubs club){
        this.clubs.add(club);
    }

    public void removeClub(Clubs club){
        this.clubs.remove(club);
    }

    public void displayClub(){
        if (this.clubs.size() == 0){
            System.out.println("No clubs to display.");
        }

        else{
            System.out.println("List of Clubs: ");
            for (String club : this.clubs){
                System.out.println(" - " + club);
            }
        }
    }
}

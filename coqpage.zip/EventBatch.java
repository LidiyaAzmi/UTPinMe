import java.util.ArrayList;

public class EventBatch{
    private ArrayList<String> events;
    
    public EventBatch(){
        this.events = new ArrayList<String>();
    }
    
    public void addEvent(Events event){
        this.events.add(event);
    }
    
    public void removeEvent(Events event){
        this.events.remove(event);
    }
    
    public void displayEvent(){
        if (this.events.size() == 0){
            System.out.println("No events to display.");
        }
        
        else{
            System.out.println("List of Events: ");
            for (String event : this.events){
                System.out.println(" - " + event);
            }
        }
    }
    
    
}

import java.util.Scanner;

/*public class CoqFeed {
    public static void main(String[] args) {

        Scanner CF = new Scanner(System.in);
        int choice;
        int feedType;
        int choiceClub;
        int choiceEvent;
        String eventDetails;
        String eventDescription;

        System.out.println("----> Choices Available For The Feed <----\n");
        System.out.println("1: Clubs");
        System.out.println("2: Events\n");

        System.out.print("Enter Your Choice Of Feed: ");
        feedType = CF.nextInt();
        CF.nextLine(); // consume leftover newline character

        choice = feedType;
        switch (feedType) {
            case 1:
                System.out.println("\nClubs");
                System.out.println("----> Amendments Available for clubs are: <----\n");
                System.out.println("1: Add Club");
                System.out.println("2: Remove Club");
                System.out.println("3: Display Club\n");

                System.out.print("Enter Your Choice Of Amendments For Clubs: ");
                choiceClub = CF.nextInt();
                CF.nextLine();
                Clubs clubs = new Clubs();
                switch (choiceClub) {
                    case 1:
                        System.out.print("Enter Club Name: ");
                        clubs.addClub(CF.nextLine());
                        break;
                    case 2:
                        System.out.print("Enter Club Name: ");
                        clubs.removeClub(CF.nextLine());
                        break;
                    case 3:
                        clubs.displayClub();
                        break;
                    default:
                        System.out.println("\nInvalid input");
                }
                break;

            case 2:
                System.out.println("\nEvents");
                System.out.println("----> Amendments Available For Events Are: <----\n");
                System.out.println("1: Add Event");
                System.out.println("2: Remove Event");
                System.out.println("3: Display Event\n");

                System.out.print("Enter Your Choice Of Amendments For Events: ");
                choiceEvent = CF.nextInt();
                CF.nextLine();
                Events events = new Events();
                switch (choiceEvent) {
                    case 1:
                        System.out.print("Enter Event Details: ");
                        eventDetails = CF.nextLine();
                        System.out.print("Enter Event Description: ");
                        eventDescription = CF.nextLine();
                        events.addEvent(eventDetails + " - " + eventDescription);
                        break;
                    case 2:
                        System.out.print("Enter Event Details: ");
                        eventDetails = CF.nextLine();
                        System.out.print("Enter Event Description: ");
                        eventDescription = CF.nextLine();
                        events.removeEvent(eventDetails + " - " + eventDescription);
                        break;
                    case 3:
                        events.displayEvent();
                        break;
                    default:
                        System.out.println("\nInvalid input");
                }
                break;

            default:
                System.out.println("\nInvalid input");
        }
    }
}*/

public class CoqFeed{
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    boolean exit = false;
    int choice;

    while (!exit) {
        System.out.println("----> Choices Available For The Feed <----\n");
        System.out.println("1: Clubs");
        System.out.println("2: Events");
        System.out.println("3: Exit\n");

        System.out.print("Enter Your Choice Of Feed: ");
        choice = input.nextInt();
        input.nextLine(); // consume leftover newline character

        switch (choice) {
            case 1:
                Clubs clubs = new Clubs();
                clubsMenu(input, clubs);
                break;
            case 2:
                Events events = new Events();
                eventsMenu(input, events);
                break;
            case 3:
                exit = true;
                System.out.println("Exiting program...");
                break;
            default:
                System.out.println("\nInvalid input");
                break;
        }

        if (!exit) {
            System.out.print("\nEnter 1 to continue, 0 to exit: ");
            choice = input.nextInt();
            input.nextLine(); // consume leftover newline character
            if (choice != 1) {
                exit = true;
                System.out.println("Exiting program...");
            }
        }
    }
}

    public static void clubsMenu(Scanner input, Clubs clubs) {
        int choice;
    
        while (true) {
            System.out.println("\n----> Amendments Available For Clubs Are: <----\n");
            System.out.println("1: Add Club");
            System.out.println("2: Remove Club");
            System.out.println("3: Display Clubs");
            System.out.println("4: Back\n");
    
            System.out.print("Enter Your Choice Of Amendments For Clubs: ");
            choice = input.nextInt();
            input.nextLine(); // consume leftover newline character
    
            switch (choice) {
                case 1:
                    System.out.print("\nEnter club name: ");
                    String clubName = input.nextLine();
                    System.out.print("Enter club event details: ");
                    String clubDetails = input.nextLine();
                    System.out.print("Enter club event description: ");
                    String clubDescription = input.nextLine();
                    clubs.addClub(clubName, clubDetails, clubDescription);
                    break;
                case 2:
                    System.out.print("\nEnter club name: ");
                    String clubNameToRemove = input.nextLine();
                    clubs.removeClub(clubNameToRemove);
                    break;
                case 3:
                    clubs.displayClub();
                    break;
                case 4:
                    return; // go back to main menu
                default:
                    System.out.println("\nInvalid input");
                    break;
            }
        }
    }
    
    public static void eventsMenu(Scanner input, Events events) {
        int choice;
    
        while (true) {
            System.out.println("\n----> Amendments Available For Events Are: <----\n");
            System.out.println("1: Add Event");
            System.out.println("2: Remove Event");
            System.out.println("3: Display Events");
            System.out.println("4: Back\n");
    
            System.out.print("Enter Your Choice Of Amendments For Events: ");
            choice = input.nextInt();
            input.nextLine(); // consume leftover newline character
    
            switch (choice) {
                case 1:
                    System.out.print("\nEnter event name: ");
                    String eventName = input.nextLine();
                    System.out.print("Enter event details: ");
                    String eventDetails = input.nextLine();
                    System.out.print("Enter event description: ");
                    String eventDescription = input.nextLine();
                    events.addEvent(eventName, eventDetails, eventDescription);
                    break;
                    
                case 2:
                    System.out.print("\nEnter event name: ");
                    String eventNameToRemove = input.nextLine();
                    events.removeEvent(eventNameToRemove);
                    break;
                    
                case 3:
                    events.displayEvent();
                    break;
                    
                case 4:
                    return; //go back to main menu 
                    
                default:
                    System.out.println("\nInvalid input");
                    break;
            }
        }
    }
}

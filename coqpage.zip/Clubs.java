public class Clubs{
    String clubName; 
    String clubDetails;
    String clubDescription;
    
    public void setName(String clubName) {
        this.clubName = clubName;
    }

    public void setDetails(String clubDetails) {
        this.clubDetails = clubDetails;
    }    
    
    public void setDescription(String clubDescription) {
        this.clubDescription = clubDescription;
    }
    
    public String getName (){
        return clubName;
    }
    
    public String getDetails (){
        return clubDetails;
    }
    
    public String getDescription (){
        return clubDescription;
    }
    
}
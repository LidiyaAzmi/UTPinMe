package com.example.mainpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.button.MaterialButton;

public class SocialsPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_socials_page);

        MaterialButton socprev = (MaterialButton) findViewById(R.id.socprev);
        MaterialButton socnext = (MaterialButton) findViewById(R.id.socnext);

        socprev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openHomePage();
            }
        });

        socnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openEduPage();
            }
        });
    }

    public void openHomePage(){
        Intent intent= new Intent(this, HomePage.class);
        startActivity(intent);
    }

    public void openEduPage(){
        Intent intent= new Intent(this, EduPage.class);
        startActivity(intent);
    }
}
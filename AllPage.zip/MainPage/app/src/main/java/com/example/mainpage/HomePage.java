package com.example.mainpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.button.MaterialButton;

public class HomePage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        MaterialButton homeprev = (MaterialButton) findViewById(R.id.homeprev);
        MaterialButton homenext = (MaterialButton) findViewById(R.id.homenext);

        homeprev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCoqPage();
            }
        });

        homenext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSocialsPage();
            }
        });
    }

    public void openSocialsPage(){
        Intent intent= new Intent(this, SocialsPage.class);
        startActivity(intent);
    }

    public void openCoqPage(){
        Intent intent= new Intent(this, CoqPage.class);
        startActivity(intent);
    }
}
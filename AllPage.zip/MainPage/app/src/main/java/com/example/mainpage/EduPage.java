package com.example.mainpage;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.button.MaterialButton;

public class EduPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edu_page);

        MaterialButton eduprev = (MaterialButton) findViewById(R.id.eduprev);
        MaterialButton edunext = (MaterialButton) findViewById(R.id.edunext);

        edunext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openCoqPage();
            }
        });

        eduprev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openSocialsPage();
            }
        });
    }
    public void openCoqPage(){
        Intent intent= new Intent(this, CoqPage.class);
        startActivity(intent);
    }

    public void openSocialsPage(){
        Intent intent= new Intent(this, SocialsPage.class);
        startActivity(intent);
    }
}
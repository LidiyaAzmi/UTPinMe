package com.example.mainpage;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.google.android.material.button.MaterialButton;

import java.util.ArrayList;

public class CoqPage extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ArrayList<Utpinme> arrayList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_coq_page);

        MaterialButton coqprev = (MaterialButton) findViewById(R.id.coqprev);
        MaterialButton coqnext = (MaterialButton) findViewById(R.id.coqnext);

        coqprev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openEduPage();
            }
        });

        coqnext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openHomePage();
            }
        });

        arrayList = new ArrayList<>();

        recyclerView = findViewById(R.id.recyclerViewofcoqpage);

        arrayList.add(new Utpinme(R.drawable.ic_launcher_background,R.drawable.ic_launcher_foreground,"title","message"));

        RecyclerAdapter recyclerAdapter = new RecyclerAdapter(arrayList);

        recyclerView.setAdapter(recyclerAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    public void openHomePage(){
        Intent intent= new Intent(this, HomePage.class);
        startActivity(intent);
    }

    public void openEduPage(){
        Intent intent= new Intent(this, EduPage.class);
        startActivity(intent);
    }
}
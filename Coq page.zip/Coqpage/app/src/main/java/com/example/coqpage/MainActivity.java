package com.example.coqpage;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class MainActivity extends AppCompatActivity {

    CardView eventcard;
    CardView clubcard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        eventcard = (CardView) findViewById(R.id.cardview1);
        clubcard = (CardView) findViewById(R.id.cardview2);

        eventcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openEvent();
            }
        });

        clubcard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openClub();
            }
        });
    }

    private void openClub() {
        Intent intent = new Intent(this, Club.class);
        startActivity(intent);
    }

    private void openEvent() {
        Intent intent = new Intent(this, EventPage.class);
        startActivity(intent);
    }
}
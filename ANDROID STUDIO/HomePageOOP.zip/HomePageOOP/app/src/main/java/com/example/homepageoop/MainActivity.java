package com.example.homepageoop;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private PostAdapter postAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<Post> postList = new ArrayList<>();
        // add your Post objects to the postList here

        postAdapter = new PostAdapter(postList);
        recyclerView.setAdapter(postAdapter);

        // create a new Post object
        Post post = new Post();

        // set the attributes using the setter methods
        post.setTitle("Title of the post");
        post.setDescription("Description of the post");
        post.setDate("2023-03-31");
        post.setTime("10:00AM");
        post.setVenue("Venue of the post");
        post.setContactNo("Contact number of the post");
        post.setContactEmail("Contact email of the post");
        post.setType("Type of the post");

        // get the values of the attributes using the getter methods
        String title = post.getTitle();
        String description = post.getDescription();
        String date = post.getDate();
        String time = post.getTime();
        String venue = post.getVenue();
        String contactNo = post.getContactNo();
        String contactEmail = post.getContactEmail();
        String type = post.getType();

        // find the TextView in the layout and set its text
        TextView titleView = findViewById(R.id.post_title);
        titleView.setText(title);
    }
}


package com.example.educationpage;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    private Button add;
    private Button remove;
    private Button notify;

    @SuppressLint("MisisingInfalted")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        add = (Button) findViewById(R.id.addSubject);
        remove = (Button) findViewById(R.id.removeSubject);
        notify = (Button) findViewById(R.id.notifyClass);

        add.setOnClickListener(this);
        remove.setOnClickListener(this);
        notify.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
    switch(view.getId()){
        case R.id.addSubject:
            openaddSubject();
            break;
        case R.id.removeSubject:
            openremoveSubject();
            break;
        case R.id.notifyClass:
            opennotifyClass();
            break;
    }
    }

    public void openaddSubject() {
        Intent intent = new Intent(this, addSubject.class);
        startActivity(intent);
    }

    public void openremoveSubject(){
        Intent intent1 = new Intent(this, removeSubject.class);
        startActivity(intent1);
    }

    public void opennotifyClass(){
        Intent intent2 = new Intent(this, notifyClass.class);
        startActivity(intent2);
    }


}






package com.example.socialpage

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var currentIndex = 0
    private lateinit var imageView: ImageView
    private lateinit var textView: TextView
    private lateinit var prevButton: Button
    private lateinit var nextButton: Button

    private val imageIds = arrayOf(R.drawable.picture1, R.drawable.picture2, R.drawable.picture3)
    private val descriptions = arrayOf("Description 1", "Description 2", "Description 3")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imageView = findViewById(R.id.imageView)
        textView = findViewById(R.id.textView)
        prevButton = findViewById(R.id.prevButton)
        nextButton = findViewById(R.id.nextButton)

        updateUI()

        prevButton.setOnClickListener {
            currentIndex--
            if (currentIndex < 0) {
                currentIndex = imageIds.size - 1
            }
            updateUI()
        }

        nextButton.setOnClickListener {
            currentIndex++
            if (currentIndex >= imageIds.size) {
                currentIndex = 0
            }
            updateUI()
        }
    }

    private fun updateUI() {
        imageView.setImageResource(imageIds[currentIndex])
        textView.text = descriptions[currentIndex]
    }
}
